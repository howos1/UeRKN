<?php
namespace app\forms;

use std, gui, framework, app;
use action\Animation; 


class MainForm extends AbstractForm
{

    /**
     * @event button.click-Left 
     */
    function doButtonClickLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event label4.click-Left 
     */
    function doLabel4ClickLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event label9.click-Left 
     */
    function doLabel9ClickLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event buttonAlt.click-Left 
     */
    function doButtonAltClickLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event keyDown-Shift+N 
     */
    function doKeyDownShiftN(UXKeyEvent $e = null)
    {    
        
    }

    /**
     * @event checkbox.click-Left 
     */
    function doCheckboxClickLeft(UXMouseEvent $e = null)
    {
        
    }















}
