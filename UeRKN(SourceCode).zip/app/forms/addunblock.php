<?php
namespace app\forms;

use std, gui, framework, app;


class addunblock extends AbstractForm
{

    /**
     * @event button2.click-Left 
     */
    function doButton2ClickLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event label4.click-Left 
     */
    function doLabel4ClickLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event label7.click-Left 
     */
    function doLabel7ClickLeft(UXMouseEvent $e = null)
    {    
        
    }






}
